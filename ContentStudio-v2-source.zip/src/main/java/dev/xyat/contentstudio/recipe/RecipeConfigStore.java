package dev.xyat.contentstudio.recipe;

import dev.xyat.kineticcore.api.text.KineticI18n;
import dev.xyat.kineticcore.api.resource.KineticResourceIds;
import dev.xyat.kineticcore.api.registry.KineticRegistries;
import dev.xyat.kineticcore.api.runtime.KineticPaths;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.logging.LogUtils;
import dev.xyat.contentstudio.recipe.removal.RemovalEntry;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.TagParser;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class RecipeConfigStore {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    public static final Path CONFIG_FILE = KineticPaths.configDirectory().resolve("kineticcore/datapack/data/contentstudio/recipe/recipe_bundle.json");
    public static final ResourceLocation DATAPACK_RESOURCE = KineticResourceIds.of("contentstudio", "recipe/recipe_bundle.json");

    private RecipeConfigStore() {
    }

    public record Snapshot(
            List<RecipeRecord> recipes,
            List<RemovalEntry> removals,
            List<JsonObject> unresolvedRecipes,
            List<RecipeRecord> invalidRecipes
    ) {
    }

    public static synchronized Snapshot load() {
        ensureFile();
        try {
            return loadRequired();
        } catch (IOException e) {
            LOGGER.error("Failed to read recipe datapack {}", CONFIG_FILE, e);
            return new Snapshot(new ArrayList<>(), new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
        }
    }

    public static synchronized Snapshot load(ResourceManager resourceManager) throws IOException {
        if (resourceManager == null) {
            throw new IOException("Recipe datapack resource manager is unavailable");
        }
        Resource resource = resourceManager.getResource(DATAPACK_RESOURCE)
                .orElseThrow(() -> new IOException("Missing recipe datapack resource " + DATAPACK_RESOURCE));
        try (java.io.Reader reader = resource.openAsReader()) {
            JsonElement rootElement = GSON.fromJson(reader, JsonElement.class);
            return parseSnapshot(rootElement);
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("Failed to parse recipe datapack resource " + DATAPACK_RESOURCE, e);
        }
    }

    public static synchronized void ensureDatapackFile() {
        ensureFile();
    }

    private static Snapshot loadRequired() throws IOException {
        ensureFile();
        try {
            JsonElement rootElement = GSON.fromJson(Files.readString(CONFIG_FILE, StandardCharsets.UTF_8), JsonElement.class);
            return parseSnapshot(rootElement);
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("Failed to parse recipe datapack", e);
        }
    }

    private static Snapshot parseSnapshot(JsonElement rootElement) throws IOException {
        if (rootElement == null || !rootElement.isJsonObject()) {
            throw new IOException("Recipe datapack root must be a JSON object");
        }
        JsonObject root = rootElement.getAsJsonObject();
        List<JsonObject> unresolvedRecipes = new ArrayList<>();
        List<RecipeRecord> invalidRecipes = new ArrayList<>();
        List<RecipeRecord> recipes = readRecipes(root, unresolvedRecipes, invalidRecipes);
        return new Snapshot(recipes, RemovalConfigCodec.readRemovals(root), unresolvedRecipes, invalidRecipes);
    }

    public static synchronized void updateRecipes(List<RecipeRecord> recipes) throws IOException {
        Snapshot current = loadRequired();
        save(recipes, current.removals(), current.unresolvedRecipes());
    }

    public static synchronized void updateRemovals(List<RemovalEntry> removals) throws IOException {
        replaceRemovalsAtomic(removals);
    }

    /** Replace only the removal field, preserving every unrelated or unrecognized config field. */
    public static synchronized void replaceRemovalsAtomic(List<RemovalEntry> removals) throws IOException {
        JsonObject root = readRootRequired();
        root.add("removals", RemovalConfigCodec.writeRemovals(removals));
        writeRootAtomic(root);
    }

    public static synchronized void save(List<RecipeRecord> recipes, List<RemovalEntry> removals) throws IOException {
        save(recipes, removals, List.of());
    }

    public static synchronized void replaceRecipeAtConfigIndex(int configIndex, RecipeRecord record) throws IOException {
        JsonObject root = readRootRequired();
        JsonArray recipes = root.has("recipes") && root.get("recipes").isJsonArray()
                ? root.getAsJsonArray("recipes")
                : new JsonArray();
        if (configIndex < 0 || configIndex >= recipes.size()) {
            throw new IOException("Recipe config index is out of range: " + configIndex);
        }
        recipes.set(configIndex, writeRecipe(record));
        root.add("recipes", recipes);
        writeRootAtomic(root);
    }

    public static synchronized void deleteRecipeAtConfigIndex(int configIndex) throws IOException {
        JsonObject root = readRootRequired();
        JsonArray recipes = root.has("recipes") && root.get("recipes").isJsonArray()
                ? root.getAsJsonArray("recipes")
                : new JsonArray();
        if (configIndex < 0 || configIndex >= recipes.size()) {
            throw new IOException("Recipe config index is out of range: " + configIndex);
        }
        recipes.remove(configIndex);
        root.add("recipes", recipes);
        writeRootAtomic(root);
    }

    private static void save(
            List<RecipeRecord> recipes,
            List<RemovalEntry> removals,
            List<JsonObject> unresolvedRecipes
    ) throws IOException {
        Files.createDirectories(CONFIG_FILE.getParent());
        JsonObject root = new JsonObject();
        root.addProperty("version", 1);

        JsonArray recipesJson = new JsonArray();
        Set<String> writtenKeys = new HashSet<>();
        for (RecipeRecord record : recipes) {
            JsonObject recipeObject = writeRecipe(record);
            recipesJson.add(recipeObject);
            String key = recipeConfigKey(recipeObject);
            if (!key.isBlank()) {
                writtenKeys.add(key);
            }
        }
        for (JsonObject unresolved : unresolvedRecipes) {
            if (unresolved == null) {
                continue;
            }
            String key = recipeConfigKey(unresolved);
            if (!key.isBlank() && writtenKeys.contains(key)) {
                continue;
            }
            recipesJson.add(unresolved.deepCopy());
        }
        root.add("recipes", recipesJson);

        root.add("removals", RemovalConfigCodec.writeRemovals(removals));

        writeRootAtomic(root);
    }

    private static JsonObject readRootRequired() throws IOException {
        ensureFile();
        try {
            JsonElement rootElement = GSON.fromJson(
                    Files.readString(CONFIG_FILE, StandardCharsets.UTF_8),
                    JsonElement.class
            );
            if (rootElement == null || !rootElement.isJsonObject()) {
                throw new IOException("Recipe datapack root must be a JSON object");
            }
            return rootElement.getAsJsonObject();
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("Failed to parse recipe datapack", e);
        }
    }

    private static void writeRootAtomic(JsonObject root) throws IOException {
        Files.createDirectories(CONFIG_FILE.getParent());
        Path tempPath = CONFIG_FILE.resolveSibling(CONFIG_FILE.getFileName() + ".tmp");
        Files.writeString(tempPath, GSON.toJson(root) + System.lineSeparator(), StandardCharsets.UTF_8);
        try {
            Files.move(tempPath, CONFIG_FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            Files.move(tempPath, CONFIG_FILE, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static void ensureFile() {
        if (Files.exists(CONFIG_FILE)) {
            return;
        }
        try {
            save(List.of(), List.of());
        } catch (IOException e) {
            LOGGER.error("Failed to create recipe datapack {}", CONFIG_FILE, e);
        }
    }

    private static List<RecipeRecord> readRecipes(
            JsonObject root,
            List<JsonObject> unresolvedRecipes,
            List<RecipeRecord> invalidRecipes
    ) {
        List<RecipeRecord> recipes = new ArrayList<>();
        JsonArray array = root.has("recipes") && root.get("recipes").isJsonArray()
                ? root.getAsJsonArray("recipes")
                : new JsonArray();

        int configIndex = 0;
        for (JsonElement element : array) {
            int currentIndex = configIndex++;
            if (!element.isJsonObject()) {
                LOGGER.warn("Skipping recipe datapack entry #{} because it is not a JSON object", currentIndex);
                continue;
            }

            JsonObject object = element.getAsJsonObject();
            String label = recipeLabel(object, currentIndex);
            try {
                RecipeRecord record = new RecipeRecord();
                record.configIndex = currentIndex;
                if (object.has("uuid")) {
                    record.uuid = validateRecipeUuid(object.get("uuid").getAsString());
                }
                record.editorType = getString(object, "editor_type", "CRAFTING");
                RecipeRegistry.EditorType editorType = RecipeRegistry.EditorType.valueOf(record.editorType);
                record.isShapeless = getBoolean(object, "shapeless", false);
                record.outputUseNbt = getBoolean(object, "output_use_nbt", false);
                record.comment = getString(object, "comment", "");

                if (!object.has("output") || !object.get("output").isJsonObject()) {
                    throw new IllegalArgumentException("missing output object");
                }
                record.output = readStack(object.getAsJsonObject("output"), false, false);
                if (record.output.isEmpty()) {
                    throw new IllegalArgumentException("output is empty");
                }

                JsonArray inputs = object.has("inputs") && object.get("inputs").isJsonArray()
                        ? object.getAsJsonArray("inputs")
                        : new JsonArray();
                for (JsonElement inputElement : inputs) {
                    if (!inputElement.isJsonObject()) {
                        throw new IllegalArgumentException("input entry is not a JSON object");
                    }
                    JsonObject inputObject = inputElement.getAsJsonObject();
                    record.inputs.add(readStack(inputObject, true, true));
                    int mode = inputObject.has("mode") ? inputObject.get("mode").getAsInt() : 0;
                    if (mode < 0 || mode > 2) {
                        throw new IllegalArgumentException("invalid input NBT mode " + mode);
                    }
                    record.inputModes.add(mode);
                }

                int required = switch (editorType) {
                    case CRAFTING -> 9;
                    case SMITHING -> 3;
                    default -> 1;
                };
                while (record.inputs.size() < required) {
                    record.inputs.add(ItemStack.EMPTY);
                    record.inputModes.add(0);
                }
                while (record.inputModes.size() < record.inputs.size()) {
                    record.inputModes.add(0);
                }

                validateRequiredInputs(record, editorType);
                recipes.add(record);
            } catch (Exception e) {
                unresolvedRecipes.add(object.deepCopy());
                invalidRecipes.add(createInvalidPlaceholder(object, currentIndex, e));
                LOGGER.warn("Skipping unusable recipe datapack entry {}: {}", label, safeMessage(e));
            }
        }
        return recipes;
    }

    private static RecipeRecord createInvalidPlaceholder(JsonObject object, int configIndex, Exception error) {
        RecipeRecord record = new RecipeRecord();
        record.invalidConfig = true;
        record.configIndex = configIndex;
        record.invalidReason = safeMessage(error);
        record.uuid = readValidUuid(object);
        record.editorType = readEditorTypeLenient(object);
        record.isShapeless = getBooleanLenient(object, "shapeless", false);
        record.outputUseNbt = getBooleanLenient(object, "output_use_nbt", false);
        record.comment = getStringLenient(object, "comment", "");

        JsonObject outputObject = object.has("output") && object.get("output").isJsonObject()
                ? object.getAsJsonObject("output")
                : null;
        record.output = outputObject == null
                ? invalidStack("?")
                : readStackLenient(outputObject, false, false);

        RecipeRegistry.EditorType type = RecipeRegistry.EditorType.valueOf(record.editorType);
        int required = requiredInputCount(type);
        JsonArray inputs = object.has("inputs") && object.get("inputs").isJsonArray()
                ? object.getAsJsonArray("inputs")
                : new JsonArray();

        for (int i = 0; i < required; i++) {
            if (i >= inputs.size()) {
                record.inputs.add(requiredSlotPlaceholder(type, i));
                record.inputModes.add(0);
                continue;
            }
            JsonElement inputElement = inputs.get(i);
            if (!inputElement.isJsonObject()) {
                record.inputs.add(invalidStack("?"));
                record.inputModes.add(0);
                continue;
            }
            JsonObject inputObject = inputElement.getAsJsonObject();
            record.inputs.add(readStackLenient(inputObject, true, true));
            int mode = inputObject.has("mode") && inputObject.get("mode").isJsonPrimitive()
                    ? getIntLenient(inputObject, "mode", 0)
                    : 0;
            record.inputModes.add(mode >= 0 && mode <= 2 ? mode : 0);
        }

        if (type == RecipeRegistry.EditorType.CRAFTING
                && record.inputs.stream().noneMatch(stack -> stack != null && !stack.isEmpty())) {
            record.inputs.set(0, invalidStack("?"));
        }
        if (type == RecipeRegistry.EditorType.SMITHING) {
            for (int i = 0; i < 3; i++) {
                if (record.inputs.get(i) == null || record.inputs.get(i).isEmpty()) {
                    record.inputs.set(i, invalidStack("?"));
                }
            }
        } else if (type != RecipeRegistry.EditorType.CRAFTING
                && (record.inputs.isEmpty() || record.inputs.get(0) == null || record.inputs.get(0).isEmpty())) {
            if (record.inputs.isEmpty()) {
                record.inputs.add(invalidStack("?"));
                record.inputModes.add(0);
            } else {
                record.inputs.set(0, invalidStack("?"));
            }
        }
        return record;
    }

    private static int requiredInputCount(RecipeRegistry.EditorType type) {
        return switch (type) {
            case CRAFTING -> 9;
            case SMITHING -> 3;
            default -> 1;
        };
    }

    private static ItemStack requiredSlotPlaceholder(RecipeRegistry.EditorType type, int index) {
        if (type == RecipeRegistry.EditorType.CRAFTING) {
            return ItemStack.EMPTY;
        }
        return invalidStack("?");
    }

    private static ItemStack readStackLenient(JsonObject object, boolean allowEmpty, boolean allowTag) {
        try {
            return readStack(object, allowEmpty, allowTag);
        } catch (Exception ignored) {
            return invalidStack(stackLabel(object));
        }
    }

    private static ItemStack invalidStack(String original) {
        ItemStack stack = new ItemStack(Items.BARRIER);
        CompoundTag tag = stack.getOrCreateTag();
        tag.putBoolean("contentstudio_invalid_placeholder", true);
        tag.putString("contentstudio_invalid_original", original == null ? "?" : original);
        stack.setHoverName(KineticI18n.translatable(
                "gui.contentstudio.recipe.recipehud.invalid_item_placeholder",
                original == null || original.isBlank() ? "?" : original
        ));
        return stack;
    }

    private static String stackLabel(JsonObject object) {
        if (object == null) return "?";
        try {
            if (object.has("item")) return object.get("item").getAsString();
            if (object.has("tag")) return object.get("tag").getAsString();
        } catch (Exception ignored) {
        }
        return "?";
    }

    private static String validateRecipeUuid(String raw) {
        if (raw == null || raw.isBlank()) {
            throw new IllegalArgumentException("recipe uuid is blank");
        }
        try {
            return java.util.UUID.fromString(raw).toString();
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("invalid recipe uuid " + raw, e);
        }
    }

    private static String readValidUuid(JsonObject object) {
        String raw = getStringLenient(object, "uuid", "");
        try {
            return java.util.UUID.fromString(raw).toString();
        } catch (Exception ignored) {
            return java.util.UUID.randomUUID().toString();
        }
    }

    private static String readEditorTypeLenient(JsonObject object) {
        String raw = getStringLenient(object, "editor_type", "CRAFTING");
        try {
            return RecipeRegistry.EditorType.valueOf(raw).name();
        } catch (Exception ignored) {
            return RecipeRegistry.EditorType.CRAFTING.name();
        }
    }

    private static String getStringLenient(JsonObject object, String key, String fallback) {
        try {
            return object.has(key) ? object.get(key).getAsString() : fallback;
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static boolean getBooleanLenient(JsonObject object, String key, boolean fallback) {
        try {
            return object.has(key) ? object.get(key).getAsBoolean() : fallback;
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static int getIntLenient(JsonObject object, String key, int fallback) {
        try {
            return object.has(key) ? object.get(key).getAsInt() : fallback;
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static JsonObject writeRecipe(RecipeRecord record) {
        JsonObject object = new JsonObject();
        object.addProperty("uuid", record.uuid);
        object.addProperty("id", memoryRecipeId(record).toString());
        object.addProperty("editor_type", record.editorType);
        object.addProperty("shapeless", record.isShapeless);
        object.addProperty("output_use_nbt", record.outputUseNbt);
        if (record.comment != null && !record.comment.isEmpty()) {
            object.addProperty("comment", record.comment);
        }
        object.add("output", writeStack(record.output, null));

        JsonArray inputs = new JsonArray();
        for (int i = 0; i < record.inputs.size(); i++) {
            int mode = i < record.inputModes.size() ? record.inputModes.get(i) : 0;
            inputs.add(writeStack(record.inputs.get(i), mode));
        }
        object.add("inputs", inputs);
        return object;
    }

    private static JsonObject writeStack(ItemStack stack, Integer mode) {
        JsonObject object = new JsonObject();
        if (mode != null) {
            object.addProperty("mode", mode);
        }
        if (stack == null || stack.isEmpty()) {
            object.addProperty("empty", true);
            return object;
        }

        CompoundTag tag = stack.getTag();
        if (tag != null && tag.contains("kt_tag")) {
            String tagId = tag.getString("kt_tag");
            if (!tagId.startsWith("#") || tagId.length() <= 1) {
                throw new IllegalArgumentException("item tag must start with #");
            }
            parseResourceLocation(tagId.substring(1), "item tag");
            object.addProperty("tag", tagId);
            return object;
        }

        ResourceLocation id = KineticRegistries.items().id(stack.getItem());
        if (id == null) {
            object.addProperty("empty", true);
            return object;
        }

        object.addProperty("item", id.toString());
        object.addProperty("count", stack.getCount());
        if (tag != null && !tag.isEmpty()) {
            object.addProperty("nbt", tag.toString());
        }
        return object;
    }

    private static ItemStack readStack(JsonObject object, boolean allowEmpty, boolean allowTag) {
        if (getBoolean(object, "empty", false)) {
            if (!allowEmpty) {
                throw new IllegalArgumentException("required stack is explicitly empty");
            }
            return ItemStack.EMPTY;
        }

        if (object.has("tag")) {
            if (!allowTag) {
                throw new IllegalArgumentException("output cannot be an item tag");
            }
            String rawTag = object.get("tag").getAsString();
            if (!rawTag.startsWith("#") || rawTag.length() <= 1) {
                throw new IllegalArgumentException("item tag must start with #");
            }
            ResourceLocation tagId = parseResourceLocation(rawTag.substring(1), "item tag");
            TagKey<Item> tagKey = TagKey.create(Registries.ITEM, tagId);
            Ingredient tagIngredient = Ingredient.of(tagKey);
            if (tagIngredient.getItems().length == 0) {
                throw new IllegalArgumentException("missing or empty item tag " + rawTag);
            }
            ItemStack tagStack = new ItemStack(Items.PAPER);
            tagStack.getOrCreateTag().putString("kt_tag", rawTag);
            tagStack.setHoverName(Component.literal(rawTag));
            return tagStack;
        }

        if (!object.has("item")) {
            throw new IllegalArgumentException("stack has neither item nor tag");
        }

        ResourceLocation id = parseResourceLocation(object.get("item").getAsString(), "item");
        if (!KineticRegistries.items().contains(id)) {
            throw new IllegalArgumentException("missing registered item " + id);
        }
        Item item = KineticRegistries.items().get(id);
        if (item == null || item == Items.AIR) {
            throw new IllegalArgumentException("missing registered item " + id);
        }

        ItemStack stack = new ItemStack(item);
        stack.setCount(Math.max(1, object.has("count") ? object.get("count").getAsInt() : 1));
        if (object.has("nbt")) {
            try {
                stack.setTag(TagParser.parseTag(object.get("nbt").getAsString()));
            } catch (Exception e) {
                throw new IllegalArgumentException("invalid NBT for item " + id, e);
            }
        }
        return stack;
    }

    private static void validateRequiredInputs(RecipeRecord record, RecipeRegistry.EditorType editorType) {
        switch (editorType) {
            case CRAFTING -> {
                boolean hasInput = false;
                for (int i = 0; i < Math.min(9, record.inputs.size()); i++) {
                    ItemStack stack = record.inputs.get(i);
                    if (stack != null && !stack.isEmpty()) {
                        hasInput = true;
                        break;
                    }
                }
                if (!hasInput) {
                    throw new IllegalArgumentException("crafting recipe has no usable ingredients");
                }
            }
            case SMITHING -> {
                for (int i = 0; i < 3; i++) {
                    if (i >= record.inputs.size() || record.inputs.get(i) == null || record.inputs.get(i).isEmpty()) {
                        throw new IllegalArgumentException("smithing recipe is missing ingredient slot " + i);
                    }
                }
            }
            default -> {
                if (record.inputs.isEmpty() || record.inputs.get(0) == null || record.inputs.get(0).isEmpty()) {
                    throw new IllegalArgumentException("recipe is missing its input ingredient");
                }
            }
        }
    }

    private static ResourceLocation parseResourceLocation(String raw, String kind) {
        if (raw == null || raw.isBlank()) {
            throw new IllegalArgumentException(kind + " id is blank");
        }
        try {
            return KineticResourceIds.parse(raw);
        } catch (Exception e) {
            throw new IllegalArgumentException("invalid " + kind + " id " + raw, e);
        }
    }


    private static String recipeConfigKey(JsonObject object) {
        if (object.has("uuid")) {
            String uuid = object.get("uuid").getAsString();
            if (!uuid.isBlank()) {
                return "uuid:" + uuid;
            }
        }
        if (object.has("id")) {
            String id = object.get("id").getAsString();
            if (!id.isBlank()) {
                return "id:" + id;
            }
        }
        return "";
    }

    private static String recipeLabel(JsonObject object, int index) {
        if (object.has("id")) {
            return object.get("id").getAsString();
        }
        if (object.has("uuid")) {
            return object.get("uuid").getAsString();
        }
        return "#" + index;
    }

    private static String safeMessage(Exception e) {
        String message = e.getMessage();
        return message == null || message.isBlank() ? e.getClass().getSimpleName() : message;
    }

    public static ResourceLocation memoryRecipeId(RecipeRecord record) {
        String value = record.uuid == null ? "" : record.uuid.replace("-", "").toLowerCase();
        if (value.isBlank()) {
            value = Integer.toHexString(System.identityHashCode(record));
        }
        return KineticResourceIds.of("contentstudio", "memory/" + value);
    }

    private static String getString(JsonObject object, String key, String fallback) {
        return object.has(key) ? object.get(key).getAsString() : fallback;
    }

    private static boolean getBoolean(JsonObject object, String key, boolean fallback) {
        return object.has(key) ? object.get(key).getAsBoolean() : fallback;
    }
}
